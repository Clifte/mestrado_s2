addpath(genpath('../util/'))
clear all; clear;clc;close all;
warning('off','all')

exportDir = '../../../../Latex/ReconhecimentoDePadroes/trabalho2/matlab/';
%%
global yl;
global lbda;
global fnc;
global parzenh;
parzenh = 0.05;

nWin = 50;
rangeParzenSearch = linspace(0.001,3,nWin);
parzenSearchResult = zeros(nWin,3);

%%
%Carrega e prepara a base
carregaPreparaBase;
%%

pTeste = 0.20;         %Percentual da base para teste
nIt = 30;              %Número de repetições para o cálculo da acurácia

%p = [1 3]; %parametro para a região de decisão. O indice indica qual atributo levar em conta
%p = [1  3];

lambda = [ 0 1 1 
           1 0 1
           1 1 0
           ];
       
fprintf('Número de repetições %d:\n',nIt);

functions = {'distEuclid','distManha','gauss','same','ndiag','diag'};
%functions = {'distManha'};
%%
for i=1:length(functions)
    fnc = cell2mat(functions(i));
    bayes_test_repete;
end
%%
atributosIris = [1 4 ;3 4];
atributosVertebra = [1 2 ;1 5];
atributosDerme = [1 16 ;1 17];


if(strcmp(base,'iris'))
    atributos = atributosIris;
else
    if(strcmp(base,'vertebra'))
       atributos = atributosVertebra;
    else
         if(strcmp(base,'derme'))
            atributos = atributosDerme;
         else
             sprintf('\n\nUNKNOWN BASE!!!\n\n')
             return;            
         end
    end
end

for i=1:length(functions)
    for j=1:length(atributos(:,1))
        close all;
        fnc = cell2mat(functions(i));
        p = atributos(j,:);
        plotaRegioesDeDecisao
    end
end

sprintf('\n\nDONE!!!\n\n')